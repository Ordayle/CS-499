// CS 405 – Module Five
// By Jordan Bankston.
//
// This program reads a text file, encrypts it using a repeating-key XOR,
// saves the encrypted data to disk, then decrypts it back to readable text.
// It also writes a small header with my name, the current date, and the key
// that was used.

#include <cassert>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

// Encrypt or decrypt text using a repeating-key XOR.
// Because XOR is its own inverse, the same function is used in both directions.
std::string encrypt_decrypt(std::string text, const std::string& key)
{
    // I want to fail fast if something is wrong with the input.
    assert(!text.empty());
    assert(!key.empty());

    const std::size_t key_length = key.length();
    const std::size_t text_length = text.length();

    // Walk through each character and XOR it with the matching key character.
    // The key wraps around using modulo so any key length is allowed.
    std::size_t key_index = 0;
    for (std::size_t i = 0; i < text_length; ++i)
    {
        text[i] = text[i] ^ key[key_index];
        key_index = (key_index + 1) % key_length;
    }

    // Sanity check: encrypting shouldn't change the length.
    assert(text.length() == text_length);

    return text;
}

// Read the entire contents of a text file into a single string.
// If the file cannot be opened, I log an error and return fallback text
// so the program still runs.
std::string read_file(const std::string& filename)
{
    std::ifstream input(filename);
    if (!input)
    {
        std::cerr << "Could not open input file: " << filename << '\n';
        return "Jordan Bankston\nInput file was not found, so this is fallback text.";
    }

    std::ostringstream buffer;
    buffer << input.rdbuf();
    return buffer.str();
}

// The first line of the file is my name. This helper pulls that out.
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;
    const std::size_t newline_pos = string_data.find('\n');

    if (newline_pos != std::string::npos)
    {
        student_name = string_data.substr(0, newline_pos);
    }

    return student_name;
}

// Save a data file in the format required by the assignment:
// Line 1: student name
// Line 2: timestamp (yyyy-mm-dd)
// Line 3: key used
// Line 4+: data (either encrypted or decrypted text)
void save_data_file(const std::string& filename,
                    const std::string& student_name,
                    const std::string& key,
                    const std::string& data)
{
    std::ofstream output(filename);
    if (!output)
    {
        std::cerr << "Could not open output file: " << filename << '\n';
        return;
    }

    // Grab the current local date.
    std::time_t now = std::time(nullptr);
    std::tm local_tm{};
#ifdef _WIN32
    localtime_s(&local_tm, &now);
#else
    local_tm = *std::localtime(&now);
#endif

    // Header lines.
    output << student_name << '\n';
    output << std::put_time(&local_tm, "%Y-%m-%d") << '\n';
    output << key << '\n';

    // Payload (plain or encrypted).
    output << data;
}

int main()
{
    std::cout << "Encryption / Decryption Test (Jordan Bankston)" << std::endl;

    // Input file format expected:
    // Line 1: my name (Jordan Bankston)
    // Line 2: Lorem Ipsum generator website used
    // Lines 3+: three paragraphs of text
    const std::string file_name           = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string key                 = "password";

    // Load the original text from disk.
    const std::string source_string = read_file(file_name);

    // Pull my name off the first line to reuse in the output files.
    const std::string student_name = get_student_name(source_string);

    // Encrypt the full file contents.
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // Save the encrypted data.
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // Decrypt back to readable text.
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // Save the decrypted data.
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: "      << file_name
              << "  -> Encrypted To: " << encrypted_file_name
              << "  -> Decrypted To: " << decrypted_file_name
              << std::endl;

    // For the assignment, I submit:
    // - inputdatafile.txt (original text)
    // - encrypteddatafile.txt
    // - decrypteddatafile.txt
    // - this source file
    // - and the key value used above.
    return 0;
}
