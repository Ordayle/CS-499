// CS 405 – Module Five Enhanced Version
// By Jordan Bankston
//
// This program reads a text file, encrypts it using a repeating-key XOR,
// saves the encrypted data to disk, then decrypts it back to readable text.
// This enhanced version improves error handling, removes the hardcoded key,
// and uses clearer validation for maintainability and security.

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

// Encrypt or decrypt text using a repeating-key XOR.
// Because XOR is its own inverse, the same function is used in both directions.
bool encrypt_decrypt(const std::string& input_text, const std::string& key, std::string& output_text)
{
    if (input_text.empty())
    {
        std::cerr << "Error: Input text is empty.\n";
        return false;
    }

    if (key.empty())
    {
        std::cerr << "Error: Encryption key cannot be empty.\n";
        return false;
    }

    output_text = input_text;
    const std::size_t key_length = key.length();
    std::size_t key_index = 0;

    for (std::size_t i = 0; i < output_text.length(); ++i)
    {
        output_text[i] = output_text[i] ^ key[key_index];
        key_index = (key_index + 1) % key_length;
    }

    return true;
}

// Read the entire contents of a file into a string.
// Returns true if successful and false if the file could not be read.
bool read_file(const std::string& filename, std::string& file_contents)
{
    std::ifstream input(filename, std::ios::binary);
    if (!input)
    {
        std::cerr << "Error: Could not open input file: " << filename << '\n';
        return false;
    }

    std::ostringstream buffer;
    buffer << input.rdbuf();
    file_contents = buffer.str();

    if (file_contents.empty())
    {
        std::cerr << "Error: Input file is empty.\n";
        return false;
    }

    return true;
}

// Save only the provided data to the output file.
// Returns true if successful and false if the file could not be written.
bool save_data_file(const std::string& filename, const std::string& data)
{
    std::ofstream output(filename, std::ios::binary);
    if (!output)
    {
        std::cerr << "Error: Could not open output file: " << filename << '\n';
        return false;
    }

    output.write(data.c_str(), static_cast<std::streamsize>(data.size()));

    if (!output)
    {
        std::cerr << "Error: Failed while writing to file: " << filename << '\n';
        return false;
    }

    return true;
}

int main()
{
    std::cout << "Encryption / Decryption Test (Jordan Bankston)\n";

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";

    std::string key;
    std::string source_string;
    std::string encrypted_string;
    std::string decrypted_string;

    std::cout << "Enter encryption key: ";
    std::getline(std::cin, key);

    if (key.empty())
    {
        std::cerr << "Error: Key cannot be empty.\n";
        return 1;
    }

    if (!read_file(file_name, source_string))
    {
        return 1;
    }

    if (!encrypt_decrypt(source_string, key, encrypted_string))
    {
        return 1;
    }

    if (!save_data_file(encrypted_file_name, encrypted_string))
    {
        return 1;
    }

    if (!encrypt_decrypt(encrypted_string, key, decrypted_string))
    {
        return 1;
    }

    if (!save_data_file(decrypted_file_name, decrypted_string))
    {
        return 1;
    }

    std::cout << "Read File: " << file_name
              << " -> Encrypted To: " << encrypted_file_name
              << " -> Decrypted To: " << decrypted_file_name
              << '\n';

    std::cout << "Encryption and decryption completed successfully.\n";
    return 0;
}
